// Simple mobile menu toggle (expand later if needed)
document.addEventListener('DOMContentLoaded', () => {
    console.log('Site Global Net Connect carregado com sucesso!');
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            if (this.getAttribute('href') !== '#') {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // WhatsApp button pulse effect
    const waBtn = document.querySelector('.whatsapp-btn');
    if (waBtn) {
        setInterval(() => {
            waBtn.style.transform = 'scale(1.05)';
            setTimeout(() => {
                waBtn.style.transform = 'scale(1)';
            }, 200);
        }, 3000);
    }
});